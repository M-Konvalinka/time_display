# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse, redirect
from time import gmtime, strftime

def index(request):
    context ={
        "time": strftime("%B %d, %Y"),
        "time2": strftime("%H:%M %p")
    }
    return render(request, 'test_app/index.html', context)